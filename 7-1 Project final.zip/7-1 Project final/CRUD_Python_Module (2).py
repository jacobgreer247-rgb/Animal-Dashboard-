from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Connection Variables
        USER = username
        PASS = password
        HOST = 'localhost'
        PORT = 27017
        DB = 'AAC'
        COL = 'animals'

        # Initialize Connection
        self.client = MongoClient(
    'mongodb://%s:%s@%s:%d/%s?authSource=admin' % (USER, PASS, HOST, PORT, DB)
)
        self.database = self.client[DB]
        self.collection = self.database[COL]

    # Create method
    def create(self, data):
        try:
            if data is not None:
                self.database.animals.insert_one(data)
                return True
            else:
                raise Exception("Nothing to save, because data parameter is empty")
        except Exception as e:
            print(e)
            return False

    # Read method
    def read(self, query):
        try:
            data = self.database.animals.find(query)
            return list(data)
        except Exception as e:
            print(e)
            return []    # Update method
    def update(self, query, new_values):
        try:
            result = self.database.animals.update_many(
                query,
                {"$set": new_values}
            )
            return result.modified_count
        except Exception as e:
            print(e)
            return 0

    # Delete method
    def delete(self, query):
        try:
            result = self.database.animals.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print(e)
            return 0